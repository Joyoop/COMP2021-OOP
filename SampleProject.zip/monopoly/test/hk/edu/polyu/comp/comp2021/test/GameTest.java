package hk.edu.polyu.comp.comp2021.test;

import hk.edu.polyu.comp.comp2021.monopoly.Game;
import org.junit.Test;

import static org.junit.Assert.*;


public class GameTest {
    @org.junit.Before
    public void setUp() throws Exception {

    }

    @Test
    public void testMain(){
        Game.main(null);
    }

}