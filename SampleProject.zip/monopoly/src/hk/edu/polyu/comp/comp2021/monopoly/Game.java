package hk.edu.polyu.comp.comp2021.monopoly;

public class Game {

    public static void main(String[] args){
        System.out.println("This is a template for the Monopoly project.");
    }
}
