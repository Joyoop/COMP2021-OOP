/**
 * Created by LX.Conan on 2016/10/23.
 */

import java.lang.*;

class Rabbit extends Runner {
    // default constructor, do not modify
    Rabbit() {
        super.name = "None";
        super.speed = 0;
        super.location = 0;
        snapChance = 0;
    }

    // please define your own constructor with proper variables
    // using keyword *super.*
    Rabbit(args1, args2, args3, args4) {
    }

    // rabbit will nap if it feels tired. The napChance is the threshold for napping.
    // if something (maybe number) is beyond napChance, the rabbit will nap a step
    void setNapChance(args) {
        // your code here
    }

    float getNapChance() {
        // your code here
    }

    // override run
    // note: if something is smaller than napChance (something < napChance),
    // the rabbit will forward with its speed (loc = loc + speed)
    public void run() {
        // your code here
    }

    // a default print state
    public void printCurrentState() {
        System.out.println("rabbit: name - " + super.name + " loc - " + super.location + " speed - " + super.speed);
    }

    private float napChance;
}