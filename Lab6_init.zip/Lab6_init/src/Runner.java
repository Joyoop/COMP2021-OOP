/**
 * Created by LX.Conan on 2016/10/23.
 */
public class Runner {

    // do not modify
    Runner() {
        name = "None";
        speed = -1;
    }

    // define your own constructor here
    Runner(args1, args2) {
    }

    // -------------------------------------------------
    // setter and getter method
    // -------------------------------------------------
    public void setName(arg) {
        // your code here
    }

    public void setSpeed(arg) {
        // your code here
    }

    public void setLocation(arg) {
        // your code here
    }

    public sig getName() {
        // your code here
    }

    public sig getSpeed() {
        // your code here
    }

    public sig getLocation() {
        // your code here
    }

    // a base run method
    public void run() {
        // your code here
        // note: loc = loc + speed
    }

    public void printCurrentState() {
        System.out.println("runner: name - " + name + " loc - " + this.location + " speed - " + this.speed);
    }

    // choosing one of three modifiers
    protected/private/public String name;
    protected/private/public float speed;
    protected/private/public float location;
}
